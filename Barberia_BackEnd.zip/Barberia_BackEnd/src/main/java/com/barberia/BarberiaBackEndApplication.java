package com.barberia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarberiaBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarberiaBackEndApplication.class, args);
	}
	
}
