package com.barberia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarberiaBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
